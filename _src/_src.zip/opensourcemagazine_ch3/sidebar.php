<!-- #right sidebar -->
<aside class="sidebar right third">
	<div class="bdr grd-vt-main rnd shdw-centered">	
		<h2 class="features embossed">Features:</h2>
		<ul class="tocNav">
			<li><a href="#">Article Name 01 Lorem ipsum dolor sit amet consectetuer adipiscing elit</a></li>
			<li><a href="#">Article Name 02 Lorem ipsum dolor sit amet</a></li>
			<li><a href="#">Article Name 03 Lorem ipsum</a></li>
		</ul>
	</div>
	<div class="bdr grd-vt-secondary rnd shdw-centered">
		<h2 class="columns embossed">Columns:</h2>
		<ul class="tocNav">
			<li><a href="#">Name of Category 01 Lorem ipsum (#)</a></li>
			<li><a href="#">Name of Category 02 Lorem (#)</a></li>
			<li><a href="#">Name of Category 03 Lorem ipsum dolor (#)</a></li>
		</ul>
	</div>
	<div class="bdr bg-light2 rnd shdw-centered">
		<h2 class="pastIssues embossed">Past Issues:</h2>
		<ul class="tocNav">
			<li><a href="#">Archive Link year/month 01</a></li>
			<li><a href="#">Archive Link year/month 02</a></li>
			<li><a href="#">Archive Link year/month 03</a></li>
		</ul>
	</div>
	<div class="push"></div>
</aside><!--//.sidebar1  -->